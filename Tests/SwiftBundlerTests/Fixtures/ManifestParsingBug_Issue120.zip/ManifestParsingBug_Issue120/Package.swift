// swift-tools-version: 6.1

import PackageDescription

let package = Package(
    name: "ManifestParsingBug",
    targets: [
        .executableTarget(
            name: "ManifestParsingBugIssue",
            resources: [.copy("NonExistentImage.png")]
        ),
    ]
)
